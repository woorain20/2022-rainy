<script>
import Main from "./main.svelte"; 
</script>
<Main></Main>
<style>
</style>