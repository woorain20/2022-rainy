﻿namespace Projectlotto
{
    partial class game
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(game));
            this.two = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.four = new System.Windows.Forms.Button();
            this.five = new System.Windows.Forms.Button();
            this.gmtitle = new System.Windows.Forms.Label();
            this.one = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.gb57 = new Projectlotto.CircularLabel();
            this.gb47 = new Projectlotto.CircularLabel();
            this.gb37 = new Projectlotto.CircularLabel();
            this.gb27 = new Projectlotto.CircularLabel();
            this.gb17 = new Projectlotto.CircularLabel();
            this.gb56 = new Projectlotto.CircularLabel();
            this.gb55 = new Projectlotto.CircularLabel();
            this.gb46 = new Projectlotto.CircularLabel();
            this.gb45 = new Projectlotto.CircularLabel();
            this.gb36 = new Projectlotto.CircularLabel();
            this.gb35 = new Projectlotto.CircularLabel();
            this.gb54 = new Projectlotto.CircularLabel();
            this.gb26 = new Projectlotto.CircularLabel();
            this.gb44 = new Projectlotto.CircularLabel();
            this.gb25 = new Projectlotto.CircularLabel();
            this.gb34 = new Projectlotto.CircularLabel();
            this.gb53 = new Projectlotto.CircularLabel();
            this.gb16 = new Projectlotto.CircularLabel();
            this.gb43 = new Projectlotto.CircularLabel();
            this.gb24 = new Projectlotto.CircularLabel();
            this.gb33 = new Projectlotto.CircularLabel();
            this.gb52 = new Projectlotto.CircularLabel();
            this.gb15 = new Projectlotto.CircularLabel();
            this.gb42 = new Projectlotto.CircularLabel();
            this.gb23 = new Projectlotto.CircularLabel();
            this.gb32 = new Projectlotto.CircularLabel();
            this.gb51 = new Projectlotto.CircularLabel();
            this.gb14 = new Projectlotto.CircularLabel();
            this.gb41 = new Projectlotto.CircularLabel();
            this.gb22 = new Projectlotto.CircularLabel();
            this.gb31 = new Projectlotto.CircularLabel();
            this.gb13 = new Projectlotto.CircularLabel();
            this.gb21 = new Projectlotto.CircularLabel();
            this.gb12 = new Projectlotto.CircularLabel();
            this.gb11 = new Projectlotto.CircularLabel();
            this.SuspendLayout();
            // 
            // two
            // 
            this.two.FlatAppearance.BorderSize = 0;
            this.two.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.two.Font = new System.Drawing.Font("1훈시나몬베이글 R", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.two.Location = new System.Drawing.Point(29, 140);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(85, 28);
            this.two.TabIndex = 0;
            this.two.Text = "2GAME";
            this.two.UseVisualStyleBackColor = true;
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // three
            // 
            this.three.FlatAppearance.BorderSize = 0;
            this.three.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.three.Font = new System.Drawing.Font("1훈시나몬베이글 R", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.three.Location = new System.Drawing.Point(29, 199);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(85, 28);
            this.three.TabIndex = 0;
            this.three.Text = "3GAME";
            this.three.UseVisualStyleBackColor = true;
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // four
            // 
            this.four.FlatAppearance.BorderSize = 0;
            this.four.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.four.Font = new System.Drawing.Font("1훈시나몬베이글 R", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.four.Location = new System.Drawing.Point(29, 258);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(85, 28);
            this.four.TabIndex = 0;
            this.four.Text = "4GAME";
            this.four.UseVisualStyleBackColor = true;
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // five
            // 
            this.five.FlatAppearance.BorderSize = 0;
            this.five.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.five.Font = new System.Drawing.Font("1훈시나몬베이글 R", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.five.Location = new System.Drawing.Point(29, 319);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(85, 28);
            this.five.TabIndex = 0;
            this.five.Text = "5GAME";
            this.five.UseVisualStyleBackColor = true;
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // gmtitle
            // 
            this.gmtitle.AutoSize = true;
            this.gmtitle.Font = new System.Drawing.Font("1훈시나몬베이글 R", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gmtitle.Location = new System.Drawing.Point(256, 38);
            this.gmtitle.Name = "gmtitle";
            this.gmtitle.Size = new System.Drawing.Size(116, 18);
            this.gmtitle.TabIndex = 1;
            this.gmtitle.Text = "자동 번호 생성기";
            // 
            // one
            // 
            this.one.FlatAppearance.BorderSize = 0;
            this.one.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.one.Font = new System.Drawing.Font("1훈시나몬베이글 R", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.one.Location = new System.Drawing.Point(29, 78);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(85, 28);
            this.one.TabIndex = 0;
            this.one.Text = "1GAME";
            this.one.UseVisualStyleBackColor = true;
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("1훈시나몬베이글 R", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(600, 30);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(61, 50);
            this.button6.TabIndex = 12;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(509, 319);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(24, 23);
            this.button5.TabIndex = 10;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(509, 258);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(24, 23);
            this.button4.TabIndex = 10;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(509, 199);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(24, 23);
            this.button3.TabIndex = 10;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(509, 140);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(24, 23);
            this.button2.TabIndex = 10;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(509, 78);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(24, 23);
            this.button1.TabIndex = 10;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // gb57
            // 
            this.gb57.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb57.FlatAppearance.BorderSize = 0;
            this.gb57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb57.Location = new System.Drawing.Point(570, 314);
            this.gb57.Name = "gb57";
            this.gb57.Size = new System.Drawing.Size(33, 33);
            this.gb57.TabIndex = 11;
            this.gb57.Text = "gb";
            this.gb57.UseVisualStyleBackColor = true;
            // 
            // gb47
            // 
            this.gb47.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb47.FlatAppearance.BorderSize = 0;
            this.gb47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb47.Location = new System.Drawing.Point(570, 254);
            this.gb47.Name = "gb47";
            this.gb47.Size = new System.Drawing.Size(33, 33);
            this.gb47.TabIndex = 11;
            this.gb47.Text = "gb";
            this.gb47.UseVisualStyleBackColor = true;
            // 
            // gb37
            // 
            this.gb37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb37.FlatAppearance.BorderSize = 0;
            this.gb37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb37.Location = new System.Drawing.Point(570, 194);
            this.gb37.Name = "gb37";
            this.gb37.Size = new System.Drawing.Size(33, 33);
            this.gb37.TabIndex = 11;
            this.gb37.Text = "gb";
            this.gb37.UseVisualStyleBackColor = true;
            // 
            // gb27
            // 
            this.gb27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb27.FlatAppearance.BorderSize = 0;
            this.gb27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb27.Location = new System.Drawing.Point(570, 135);
            this.gb27.Name = "gb27";
            this.gb27.Size = new System.Drawing.Size(33, 33);
            this.gb27.TabIndex = 11;
            this.gb27.Text = "gb";
            this.gb27.UseVisualStyleBackColor = true;
            // 
            // gb17
            // 
            this.gb17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb17.FlatAppearance.BorderSize = 0;
            this.gb17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb17.Location = new System.Drawing.Point(570, 74);
            this.gb17.Name = "gb17";
            this.gb17.Size = new System.Drawing.Size(33, 33);
            this.gb17.TabIndex = 11;
            this.gb17.Text = "gb";
            this.gb17.UseVisualStyleBackColor = true;
            // 
            // gb56
            // 
            this.gb56.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb56.FlatAppearance.BorderSize = 0;
            this.gb56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb56.Location = new System.Drawing.Point(439, 314);
            this.gb56.Name = "gb56";
            this.gb56.Size = new System.Drawing.Size(33, 33);
            this.gb56.TabIndex = 11;
            this.gb56.Text = "gb";
            this.gb56.UseVisualStyleBackColor = true;
            // 
            // gb55
            // 
            this.gb55.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb55.FlatAppearance.BorderSize = 0;
            this.gb55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb55.Location = new System.Drawing.Point(380, 314);
            this.gb55.Name = "gb55";
            this.gb55.Size = new System.Drawing.Size(33, 33);
            this.gb55.TabIndex = 11;
            this.gb55.Text = "gb";
            this.gb55.UseVisualStyleBackColor = true;
            // 
            // gb46
            // 
            this.gb46.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb46.FlatAppearance.BorderSize = 0;
            this.gb46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb46.Location = new System.Drawing.Point(439, 254);
            this.gb46.Name = "gb46";
            this.gb46.Size = new System.Drawing.Size(33, 33);
            this.gb46.TabIndex = 11;
            this.gb46.Text = "gb";
            this.gb46.UseVisualStyleBackColor = true;
            // 
            // gb45
            // 
            this.gb45.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb45.FlatAppearance.BorderSize = 0;
            this.gb45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb45.Location = new System.Drawing.Point(380, 254);
            this.gb45.Name = "gb45";
            this.gb45.Size = new System.Drawing.Size(33, 33);
            this.gb45.TabIndex = 11;
            this.gb45.Text = "gb";
            this.gb45.UseVisualStyleBackColor = true;
            // 
            // gb36
            // 
            this.gb36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb36.FlatAppearance.BorderSize = 0;
            this.gb36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb36.Location = new System.Drawing.Point(439, 194);
            this.gb36.Name = "gb36";
            this.gb36.Size = new System.Drawing.Size(33, 33);
            this.gb36.TabIndex = 11;
            this.gb36.Text = "gb";
            this.gb36.UseVisualStyleBackColor = true;
            // 
            // gb35
            // 
            this.gb35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb35.FlatAppearance.BorderSize = 0;
            this.gb35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb35.Location = new System.Drawing.Point(380, 194);
            this.gb35.Name = "gb35";
            this.gb35.Size = new System.Drawing.Size(33, 33);
            this.gb35.TabIndex = 11;
            this.gb35.Text = "gb";
            this.gb35.UseVisualStyleBackColor = true;
            // 
            // gb54
            // 
            this.gb54.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb54.FlatAppearance.BorderSize = 0;
            this.gb54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb54.Location = new System.Drawing.Point(319, 314);
            this.gb54.Name = "gb54";
            this.gb54.Size = new System.Drawing.Size(33, 33);
            this.gb54.TabIndex = 11;
            this.gb54.Text = "gb";
            this.gb54.UseVisualStyleBackColor = true;
            // 
            // gb26
            // 
            this.gb26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb26.FlatAppearance.BorderSize = 0;
            this.gb26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb26.Location = new System.Drawing.Point(439, 135);
            this.gb26.Name = "gb26";
            this.gb26.Size = new System.Drawing.Size(33, 33);
            this.gb26.TabIndex = 11;
            this.gb26.Text = "gb";
            this.gb26.UseVisualStyleBackColor = true;
            // 
            // gb44
            // 
            this.gb44.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb44.FlatAppearance.BorderSize = 0;
            this.gb44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb44.Location = new System.Drawing.Point(319, 254);
            this.gb44.Name = "gb44";
            this.gb44.Size = new System.Drawing.Size(33, 33);
            this.gb44.TabIndex = 11;
            this.gb44.Text = "gb";
            this.gb44.UseVisualStyleBackColor = true;
            // 
            // gb25
            // 
            this.gb25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb25.FlatAppearance.BorderSize = 0;
            this.gb25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb25.Location = new System.Drawing.Point(380, 135);
            this.gb25.Name = "gb25";
            this.gb25.Size = new System.Drawing.Size(33, 33);
            this.gb25.TabIndex = 11;
            this.gb25.Text = "gb";
            this.gb25.UseVisualStyleBackColor = true;
            // 
            // gb34
            // 
            this.gb34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb34.FlatAppearance.BorderSize = 0;
            this.gb34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb34.Location = new System.Drawing.Point(319, 194);
            this.gb34.Name = "gb34";
            this.gb34.Size = new System.Drawing.Size(33, 33);
            this.gb34.TabIndex = 11;
            this.gb34.Text = "gb";
            this.gb34.UseVisualStyleBackColor = true;
            // 
            // gb53
            // 
            this.gb53.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb53.FlatAppearance.BorderSize = 0;
            this.gb53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb53.Location = new System.Drawing.Point(259, 314);
            this.gb53.Name = "gb53";
            this.gb53.Size = new System.Drawing.Size(33, 33);
            this.gb53.TabIndex = 11;
            this.gb53.Text = "gb";
            this.gb53.UseVisualStyleBackColor = true;
            // 
            // gb16
            // 
            this.gb16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb16.FlatAppearance.BorderSize = 0;
            this.gb16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb16.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb16.ForeColor = System.Drawing.Color.Black;
            this.gb16.Location = new System.Drawing.Point(439, 74);
            this.gb16.Name = "gb16";
            this.gb16.Size = new System.Drawing.Size(33, 33);
            this.gb16.TabIndex = 11;
            this.gb16.Text = "gb";
            this.gb16.UseVisualStyleBackColor = true;
            // 
            // gb43
            // 
            this.gb43.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb43.FlatAppearance.BorderSize = 0;
            this.gb43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb43.Location = new System.Drawing.Point(259, 254);
            this.gb43.Name = "gb43";
            this.gb43.Size = new System.Drawing.Size(33, 33);
            this.gb43.TabIndex = 11;
            this.gb43.Text = "gb";
            this.gb43.UseVisualStyleBackColor = true;
            // 
            // gb24
            // 
            this.gb24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb24.FlatAppearance.BorderSize = 0;
            this.gb24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb24.Location = new System.Drawing.Point(319, 135);
            this.gb24.Name = "gb24";
            this.gb24.Size = new System.Drawing.Size(33, 33);
            this.gb24.TabIndex = 11;
            this.gb24.Text = "gb";
            this.gb24.UseVisualStyleBackColor = true;
            // 
            // gb33
            // 
            this.gb33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb33.FlatAppearance.BorderSize = 0;
            this.gb33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb33.Location = new System.Drawing.Point(259, 194);
            this.gb33.Name = "gb33";
            this.gb33.Size = new System.Drawing.Size(33, 33);
            this.gb33.TabIndex = 11;
            this.gb33.Text = "gb";
            this.gb33.UseVisualStyleBackColor = true;
            // 
            // gb52
            // 
            this.gb52.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb52.FlatAppearance.BorderSize = 0;
            this.gb52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb52.Location = new System.Drawing.Point(200, 314);
            this.gb52.Name = "gb52";
            this.gb52.Size = new System.Drawing.Size(33, 33);
            this.gb52.TabIndex = 11;
            this.gb52.Text = "gb";
            this.gb52.UseVisualStyleBackColor = true;
            // 
            // gb15
            // 
            this.gb15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb15.FlatAppearance.BorderSize = 0;
            this.gb15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb15.Location = new System.Drawing.Point(380, 74);
            this.gb15.Name = "gb15";
            this.gb15.Size = new System.Drawing.Size(33, 33);
            this.gb15.TabIndex = 11;
            this.gb15.Text = "gb";
            this.gb15.UseVisualStyleBackColor = true;
            // 
            // gb42
            // 
            this.gb42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb42.FlatAppearance.BorderSize = 0;
            this.gb42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb42.Location = new System.Drawing.Point(200, 254);
            this.gb42.Name = "gb42";
            this.gb42.Size = new System.Drawing.Size(33, 33);
            this.gb42.TabIndex = 11;
            this.gb42.Text = "gb";
            this.gb42.UseVisualStyleBackColor = true;
            // 
            // gb23
            // 
            this.gb23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb23.FlatAppearance.BorderSize = 0;
            this.gb23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb23.Location = new System.Drawing.Point(259, 135);
            this.gb23.Name = "gb23";
            this.gb23.Size = new System.Drawing.Size(33, 33);
            this.gb23.TabIndex = 11;
            this.gb23.Text = "gb";
            this.gb23.UseVisualStyleBackColor = true;
            // 
            // gb32
            // 
            this.gb32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb32.FlatAppearance.BorderSize = 0;
            this.gb32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb32.Location = new System.Drawing.Point(200, 194);
            this.gb32.Name = "gb32";
            this.gb32.Size = new System.Drawing.Size(33, 33);
            this.gb32.TabIndex = 11;
            this.gb32.Text = "gb";
            this.gb32.UseVisualStyleBackColor = true;
            // 
            // gb51
            // 
            this.gb51.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb51.FlatAppearance.BorderSize = 0;
            this.gb51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb51.Location = new System.Drawing.Point(139, 314);
            this.gb51.Name = "gb51";
            this.gb51.Size = new System.Drawing.Size(33, 33);
            this.gb51.TabIndex = 11;
            this.gb51.Text = "gb";
            this.gb51.UseVisualStyleBackColor = true;
            // 
            // gb14
            // 
            this.gb14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb14.FlatAppearance.BorderSize = 0;
            this.gb14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb14.Location = new System.Drawing.Point(319, 74);
            this.gb14.Name = "gb14";
            this.gb14.Size = new System.Drawing.Size(33, 33);
            this.gb14.TabIndex = 11;
            this.gb14.Text = "gb";
            this.gb14.UseVisualStyleBackColor = true;
            // 
            // gb41
            // 
            this.gb41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb41.FlatAppearance.BorderSize = 0;
            this.gb41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb41.Location = new System.Drawing.Point(139, 254);
            this.gb41.Name = "gb41";
            this.gb41.Size = new System.Drawing.Size(33, 33);
            this.gb41.TabIndex = 11;
            this.gb41.Text = "gb";
            this.gb41.UseVisualStyleBackColor = true;
            // 
            // gb22
            // 
            this.gb22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb22.FlatAppearance.BorderSize = 0;
            this.gb22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb22.Location = new System.Drawing.Point(200, 135);
            this.gb22.Name = "gb22";
            this.gb22.Size = new System.Drawing.Size(33, 33);
            this.gb22.TabIndex = 11;
            this.gb22.Text = "gb";
            this.gb22.UseVisualStyleBackColor = true;
            // 
            // gb31
            // 
            this.gb31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb31.FlatAppearance.BorderSize = 0;
            this.gb31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb31.Location = new System.Drawing.Point(139, 194);
            this.gb31.Name = "gb31";
            this.gb31.Size = new System.Drawing.Size(33, 33);
            this.gb31.TabIndex = 11;
            this.gb31.Text = "gb";
            this.gb31.UseVisualStyleBackColor = true;
            // 
            // gb13
            // 
            this.gb13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb13.FlatAppearance.BorderSize = 0;
            this.gb13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb13.Location = new System.Drawing.Point(259, 74);
            this.gb13.Name = "gb13";
            this.gb13.Size = new System.Drawing.Size(33, 33);
            this.gb13.TabIndex = 11;
            this.gb13.Text = "gb";
            this.gb13.UseVisualStyleBackColor = true;
            // 
            // gb21
            // 
            this.gb21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb21.FlatAppearance.BorderSize = 0;
            this.gb21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb21.Location = new System.Drawing.Point(139, 135);
            this.gb21.Name = "gb21";
            this.gb21.Size = new System.Drawing.Size(33, 33);
            this.gb21.TabIndex = 11;
            this.gb21.Text = "gb";
            this.gb21.UseVisualStyleBackColor = true;
            // 
            // gb12
            // 
            this.gb12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb12.FlatAppearance.BorderSize = 0;
            this.gb12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb12.Location = new System.Drawing.Point(200, 74);
            this.gb12.Name = "gb12";
            this.gb12.Size = new System.Drawing.Size(33, 33);
            this.gb12.TabIndex = 11;
            this.gb12.Text = "gb";
            this.gb12.UseVisualStyleBackColor = true;
            // 
            // gb11
            // 
            this.gb11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gb11.FlatAppearance.BorderSize = 0;
            this.gb11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb11.Location = new System.Drawing.Point(139, 74);
            this.gb11.Name = "gb11";
            this.gb11.Size = new System.Drawing.Size(33, 33);
            this.gb11.TabIndex = 11;
            this.gb11.Text = "gb";
            this.gb11.UseVisualStyleBackColor = true;
            // 
            // game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button6);
            this.Controls.Add(this.gb57);
            this.Controls.Add(this.gb47);
            this.Controls.Add(this.gb37);
            this.Controls.Add(this.gb27);
            this.Controls.Add(this.gb17);
            this.Controls.Add(this.gb56);
            this.Controls.Add(this.gb55);
            this.Controls.Add(this.gb46);
            this.Controls.Add(this.gb45);
            this.Controls.Add(this.gb36);
            this.Controls.Add(this.gb35);
            this.Controls.Add(this.gb54);
            this.Controls.Add(this.gb26);
            this.Controls.Add(this.gb44);
            this.Controls.Add(this.gb25);
            this.Controls.Add(this.gb34);
            this.Controls.Add(this.gb53);
            this.Controls.Add(this.gb16);
            this.Controls.Add(this.gb43);
            this.Controls.Add(this.gb24);
            this.Controls.Add(this.gb33);
            this.Controls.Add(this.gb52);
            this.Controls.Add(this.gb15);
            this.Controls.Add(this.gb42);
            this.Controls.Add(this.gb23);
            this.Controls.Add(this.gb32);
            this.Controls.Add(this.gb51);
            this.Controls.Add(this.gb14);
            this.Controls.Add(this.gb41);
            this.Controls.Add(this.gb22);
            this.Controls.Add(this.gb31);
            this.Controls.Add(this.gb13);
            this.Controls.Add(this.gb21);
            this.Controls.Add(this.gb12);
            this.Controls.Add(this.gb11);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gmtitle);
            this.Controls.Add(this.five);
            this.Controls.Add(this.four);
            this.Controls.Add(this.three);
            this.Controls.Add(this.one);
            this.Controls.Add(this.two);
            this.Name = "game";
            this.Size = new System.Drawing.Size(684, 402);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button four;
        private System.Windows.Forms.Button five;
        private System.Windows.Forms.Label gmtitle;
        private System.Windows.Forms.Button one;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private CircularLabel gb11;
        private CircularLabel gb12;
        private CircularLabel gb13;
        private CircularLabel gb14;
        private CircularLabel gb15;
        private CircularLabel gb16;
        private CircularLabel gb17;
        private CircularLabel gb21;
        private CircularLabel gb22;
        private CircularLabel gb23;
        private CircularLabel gb24;
        private CircularLabel gb25;
        private CircularLabel gb26;
        private CircularLabel gb31;
        private CircularLabel gb32;
        private CircularLabel gb33;
        private CircularLabel gb34;
        private CircularLabel gb35;
        private CircularLabel gb36;
        private CircularLabel gb41;
        private CircularLabel gb42;
        private CircularLabel gb43;
        private CircularLabel gb44;
        private CircularLabel gb45;
        private CircularLabel gb46;
        private CircularLabel gb51;
        private CircularLabel gb52;
        private CircularLabel gb53;
        private CircularLabel gb54;
        private CircularLabel gb55;
        private CircularLabel gb56;
        private CircularLabel gb27;
        private CircularLabel gb37;
        private CircularLabel gb47;
        private CircularLabel gb57;
        private System.Windows.Forms.Button button6;
    }
}
